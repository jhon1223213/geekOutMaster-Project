package JuegoCraps;

import javax.swing.*;
import java.awt.*;

/**
 * Clase genera la creacion de encabezado predefinido en la interfaz.
 * @author Jhon Frank Vasquez - jhon.frank.vasquez@correounivalle.edu.co - 2226510
 * @author Juan Felipe Palechor - juanfelipepalechor@gmail.com - 2270963
 * @version v.1.0.0 16/05/23
 */

public class Headers extends JLabel {

    public Headers(String title, Color colorBackground){

        this.setText(title);
        this.setBackground(colorBackground);
        this.setForeground(new Color(255,255,255));
        this.setFont(new Font(Font.DIALOG,Font.BOLD,20));
        this.setHorizontalAlignment(JLabel.CENTER);
        this.setVerticalAlignment(JLabel.CENTER);
        this.setOpaque(true);


    }
}