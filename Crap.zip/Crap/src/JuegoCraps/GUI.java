package JuegoCraps;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

/**
 * clase GUI LA VISTA
 * @author Jhon Frank Vasquez - jhon.frank.vasquez@correounivalle.edu.co - 2226510
 * @author Juan Felipe Palechor - juanfelipepalechor@gmail.com - 2270963
 * @version v.1.0.0 16/05/23
 */
public class GUI extends JFrame {

    public static final String MENSAJE_INICIO="jj";

    private Headers headersProjects;
    private JLabel dado1,dado2,dado3,dado4,dado5,dado6,dado7,dado8,dado9,dado10;
    private JButton lanzar;
    private JPanel DadosActivos,DadosInactivos,Targeta,DadosUtilizados;
    private ImageIcon imageDado;
    private JTextArea resultados;

    private Escucha escucha;

    private Reglas reglas;



    public GUI(){
        initGUI();

        this.setTitle("Juego Craps");
        this.setSize(900,800);
        this.pack();

        this.setResizable(true);
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



    }



    private void initGUI() {

        escucha = new Escucha();


        reglas = new Reglas();

        headersProjects=new Headers("Mesa Juego Craps", Color.BLACK);

        this.add(headersProjects,BorderLayout.NORTH);

        imageDado = new ImageIcon(getClass().getResource("/Recursos/dado.png"));

        dado1= new JLabel(imageDado);
        dado2= new JLabel(imageDado);
        dado3= new JLabel(imageDado);
        dado4= new JLabel(imageDado);
        dado5= new JLabel(imageDado);
        dado6= new JLabel(imageDado);
        dado7= new JLabel(imageDado);
        dado8= new JLabel(imageDado);
        dado9= new JLabel(imageDado);
        dado10= new JLabel(imageDado);



        lanzar = new JButton("lanzar");
        lanzar.addActionListener(escucha);
        // Obtener la imagen original
        ImageIcon imageDadoOriginal = new ImageIcon(getClass().getResource("/Recursos/dado.png"));

        // Escalar la imagen a un tamaño más pequeño
        Image imageDadoEscalado = imageDadoOriginal.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);

        // Crear un nuevo ImageIcon con la imagen escalada
        ImageIcon imageDado = new ImageIcon(imageDadoEscalado);

        // Crear un JLabel con el nuevo ImageIcon
        dado1 = new JLabel(imageDado);
        dado2 = new JLabel(imageDado);
        dado3 = new JLabel(imageDado);
        dado4 = new JLabel(imageDado);
        dado5 = new JLabel(imageDado);
        dado6 = new JLabel(imageDado);
        dado7 = new JLabel(imageDado);
        dado8 = new JLabel(imageDado);
        dado9 = new JLabel(imageDado);
        dado10 = new JLabel(imageDado);


        DadosActivos = new JPanel();
        DadosInactivos = new JPanel();
        Targeta = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        DadosUtilizados = new JPanel();


        DadosActivos.setPreferredSize(new Dimension(670,360));
        DadosActivos.setBackground(Color.RED);
        DadosInactivos.setPreferredSize(new Dimension(670,360));
        DadosInactivos.setBackground(Color.BLUE);
        Targeta.setPreferredSize(new Dimension(670,340));
        Targeta.setBackground(Color.CYAN);
        DadosUtilizados.setPreferredSize(new Dimension(670,340));
        DadosUtilizados.setBackground(Color.BLACK);

        DadosActivos.setBorder(BorderFactory.createTitledBorder("Tus dados"));
        DadosInactivos.setBorder(BorderFactory.createTitledBorder("dados inactivos"));
        Targeta.setBorder(BorderFactory.createTitledBorder("Targeta puntuacion"));
        DadosUtilizados.setBorder(BorderFactory.createTitledBorder("dados utilizados"));


        DadosActivos.add(dado1);
        DadosActivos.add(dado2);
        DadosActivos.add(dado3);
        DadosActivos.add(dado4);
        DadosActivos.add(dado5);
        DadosActivos.add(dado6);
        DadosActivos.add(dado7);
        DadosInactivos.add(dado8);
        DadosInactivos.add(dado9);
        DadosInactivos.add(dado10);






        DadosActivos.add(lanzar);






        // Crear un panel contenedor para los paneles de arriba y establecer su disposición
        JPanel PanelArriba = new JPanel();
        PanelArriba.setLayout(new FlowLayout(FlowLayout.LEFT));
        PanelArriba.add(DadosActivos);
        PanelArriba.add(DadosInactivos);

        // Crear un panel contenedor para los paneles de abajo y establecer su disposición
        JPanel panelAbajo = new JPanel();
        panelAbajo.setLayout(new FlowLayout(FlowLayout.RIGHT));
        panelAbajo.add(Targeta);
        panelAbajo.add(DadosUtilizados);

        // Agregar los paneles al contenedor principal
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(PanelArriba, BorderLayout.NORTH);
        getContentPane().add(panelAbajo, BorderLayout.SOUTH);

        /**
         *

        this.add(DadosActivos,BorderLayout.CENTER);
        this.add(DadosInactivos,BorderLayout.EAST);
        this.add(DadosInactivos,BorderLayout.SOUTH);
        this.add(DadosInactivos,BorderLayout.SOUTH);


         */


        JScrollPane scroll = new JScrollPane(resultados);
        this.add(scroll,BorderLayout.EAST);



    }

    public static void main(String[] args){

        EventQueue.invokeLater(()->{
            GUI miProjectGUI= new GUI();

        });



    }

    private class Escucha implements ActionListener {

        ImageIcon imageDadoOriginal = new ImageIcon(getClass().getResource("/Recursos/corazon.jpg"));

        // Escalar la imagen a un tamaño más pequeño
        Image imageDadoEscalado = imageDadoOriginal.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);

        // Crear un nuevo ImageIcon con la imagen escalada
        ImageIcon imageDado = new ImageIcon(imageDadoEscalado);


        @Override
        public void actionPerformed(ActionEvent e) {
            reglas.calculartiro();
            int [] caras = reglas.getCaras();
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[0]+"dado.png"));
            dado1.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[1]+"meaple.jpg"));
            dado2.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[2]+"dragon.jpg"));
            dado3.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[3]+"corazon.jpg"));
            dado4.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[4]+"cohete.jpg"));
            dado5.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[5]+"super.jpg"));
            dado6.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[6]+""));
            dado7.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[7]+".png"));
            dado8.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[8]+".png"));
            dado9.setIcon(imageDado);
            imageDado = new ImageIcon(getClass().getResource("/Recursos/"+caras[9]+".png"));
            dado10.setIcon(imageDado);






        }
    }



}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
